﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace $safeprojectname$
{
    public partial class XtraReport_standard : DevExpress.XtraReports.UI.XtraReport
    {
        public XtraReport_standard()
        {
            InitializeComponent();

             }

    }
}
